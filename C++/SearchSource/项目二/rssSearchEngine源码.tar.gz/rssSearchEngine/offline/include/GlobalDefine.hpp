 ///
 /// @file    GlobalDefine.hpp
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2016-01-18 15:03:02
 ///


#ifndef _WD_GLOBAL_DEFINE_H_
#define _WD_GLOBAL_DEFINE_H_

#define YULIAO_KEY       "yuliao"
#define TITLEFEATURE_KEY "titlefeature"
#define RIPEPAGELIB_KEY  "ripepagelib"
#define OFFSETLIB_KEY    "offsetlib"
#define STOP_WORD_KEY    "stopword"
#define NEWPAGELIB_KEY   "newpagelib"
#define NEWOFFSETLIB_KEY "newoffsetlib"
#define INVERTINDEX_KEY  "invertindexlib"

#endif
